<script src="js/jquery-3.3.1.min.js"></script>
    <script src="<?php echo base_url().'assets/js/jquery-migrate-3.0.0.js '?>"></script>
    <script src="<?php echo base_url().'assets/js/popper.min.js' ?>"></script>
    <script src="<?php echo base_url().'assets/js/bootstrap.min.js' ?>"></script>
    <script src="<?php echo base_url().'assets/js/owl.carousel.min.js' ?> " ></script>
    <script src="<?php echo base_url().'assets/js/jquery.sticky.js' ?>"></script>
    <script src="<?php echo base_url().'assets/js/jquery.waypoints.min.js' ?>"></script>
    <script src="<?php echo base_url().'assets/js/jquery.animateNumber.min.js' ?>"></script>
    <script src="<?php echo base_url().'assets/js/jquery.fancybox.min.js' ?>"></script>
    <script src="<?php echo base_url().'assets/js/jquery.stellar.min.js' ?>"></script>
    <script src="<?php echo base_url().'assets/js/jquery.easing.1.3.js' ?>"></script>
    <script src="<?php echo base_url().'assets/js/bootstrap-datepicker.min.js' ?>"></script>
    <script src="<?php echo base_url().'assets/js/aos.js' ?>"></script>

    <script src="<?php echo base_url().'assets/js/main.js' ?>"></script>

</body>
</html>