<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://fonts.googleapis.com/css?family=DM+Sans:300,400,700&display=swap" rel="stylesheet">

<style>
    .gambar{
        width: 200px;
        height: 200px;
    }
</style>
<link rel="stylesheet" href="<?php echo base_url().'assets/css"fonts/icomoon/style.css' ?>">
<link rel="stylesheet" href="<?php echo base_url().'assets/css/bootstrap.min.css' ?>">
<link rel="stylesheet" href="<?php echo base_url().'assets/css/bootstrap-datepicker.css' ?>">
<link rel="stylesheet" href="<?php echo base_url().'assets/css/jquery.fancybox.min.css' ?>">
<link rel="stylesheet" href="<?php echo base_url().'assets/css/owl.carousel.min.css' ?>">
<link rel="stylesheet" href="<?php echo base_url().'assets/css/owl.theme.default.min.css' ?>">
<link rel="stylesheet" href="<?php echo base_url().'assets/fonts/flaticon/font/flaticon.css' ?>">
<link rel="stylesheet" href="<?php echo base_url().'assets/css/aos.css' ?>">
<!-- MAIN CSS -->
<link rel="stylesheet" href="<?php echo base_url().'assets/css/style.css' ?>">

</head>
<body>
    