$.getJSON("coba2.json",
    function (data){
        console.log(data);
    }
);