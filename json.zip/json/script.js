let mahasiswa={
nama:"dino",
nim:"2012092113",
email:"dino@gmail.com"
}
console.log(JSON.stringify(mahasiswa));
console.log(mahasiswa);