<?php
$mahasiswa=[
    "nama" => "dina kurnia sari",
    "nim" => 20130811201,
    "email" => "dina@gmail.com"
];

    $data=json_encode($mahasiswa);
    echo $data;
    ?>