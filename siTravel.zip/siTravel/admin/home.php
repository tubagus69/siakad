 
<div class="row">
    
<div class="box col-md-12">
        <div class="box-inner">
            <div class="box-header well">
                <h2>Beranda</h2>

                <div class="box-icon">
                    <a href="#" class="btn btn-setting btn-round btn-default"><i
                            class="glyphicon glyphicon-cog"></i></a>
                    <a href="#" class="btn btn-minimize btn-round btn-default"><i
                            class="glyphicon glyphicon-chevron-up"></i></a>
                    <a href="#" class="btn btn-close btn-round btn-default"><i
                            class="glyphicon glyphicon-remove"></i></a>
                </div>
            </div>
            <div class="box-content row">
                <div class="col-lg-7 col-md-12">
                    <h1>Selamat Datang <?PHP echo" $_SESSION[login_username]";?> <br></h1>
                    <p>Jangan lupa untuk selalu sign out setelah anda menggunakan halaman ini dan biasakan
	secara rutin untuk mengganti password admin anda setiap 1-2 bulan.<br><br><br></p>

              </div>     

                   
                </div>
                

            </div>
        </div>
    </div>