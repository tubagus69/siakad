
<div id="atas">
					<div id="logo">
						<div class='logo2'><img src='img/logo5.png' width='70px' height='60px'></div><div class='logo3'>Tour & Travel</div>
					</div>
		<div id="menu">
						<ul>
							<li><a href="index.php?page2=intro">BERANDA<span class="menuHighlight"></span></a></li>
							<li><a href="index.php?page2=tentangkami">TENTANG KAMI<span class="menuHighlight"></span></a></li>
							<li><a href="index.php?page2=kontakkami">KONTAK KAMI<span class="menuHighlight"></span></a></li>
							<li><a href="index.php?page2=register">DAFTAR<span class="menuHighlight"></span></a></li>
							<li><a href="login.php">LOGIN<span class="menuHighlight"></span></a></li>
							
						</ul>
		</div>
		</div>