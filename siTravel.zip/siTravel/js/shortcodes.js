(function() {
  "use strict";


/* ---------------------------------------------------------------------- */
/*         Shortcodes Main Javascript FIle
/* ---------------------------------------------------------------------- */

//Javascipt Scripting Starts Here


}()); 



