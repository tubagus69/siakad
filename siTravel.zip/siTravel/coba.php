<p>bellajar </p>
<form action='#' method='post'>
<input type='hidden' name='asal'>
<input type='submit' value='kirimpesan'>
</form>