<script type="text/javascript">
    $(document).ready( function () {
        $('#myTable').DataTable();
    });

</script>