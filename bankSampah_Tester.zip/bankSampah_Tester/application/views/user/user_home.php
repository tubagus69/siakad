<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <div>
        <div class="text-center text-success">
            <img src="<?php echo base_url('assets/img/home/banksampah.jpg'); ?>" width="600px" height="600px" class="img-fluid">
            <br><br><br>
            <H5>Join Our System</H5>
            <h6>Be the first to save trash and enjoy the garbage pick-up service</h6>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->