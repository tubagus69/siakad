<script type="text/javascript">
    $(document).ready( function () {
        $('#myTable').DataTable();
    });

</script>
<footer class="text-center" style="width:100" >
  <a class="up-arrow" href="#myPage" data-toggle="tooltip" title="TO TOP">
    <span class="glyphicon glyphicon-chevron-up"></span>
  </a><br><br>
  <p>Copyright ©AdePutra&Tubagus</p> 
</footer>